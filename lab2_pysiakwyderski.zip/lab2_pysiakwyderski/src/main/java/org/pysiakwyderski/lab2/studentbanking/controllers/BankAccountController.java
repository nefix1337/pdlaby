package org.pysiakwyderski.lab2.studentbanking.controllers;

import org.pysiakwyderski.lab2.studentbanking.models.BankAccount;
import org.pysiakwyderski.lab2.studentbanking.models.Transaction;
import org.pysiakwyderski.lab2.studentbanking.services.BankAccountService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class BankAccountController {

    private final BankAccountService bankAccountService;

    public BankAccountController(BankAccountService bankAccountService) {
        this.bankAccountService = bankAccountService;
    }

    @PostMapping
    public ResponseEntity<BankAccount> createAccount(@Valid @RequestBody BankAccount account) {
        bankAccountService.saveAccount(account);
        return ResponseEntity.ok(account);
    }

    @GetMapping("/{pesel}")
    public ResponseEntity<BankAccount> getAccount(@PathVariable String pesel) {
        BankAccount account = bankAccountService.loadAccount(pesel);
        if (account != null) {
            return ResponseEntity.ok(account);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/{pesel}/deposit")
    public ResponseEntity<Void> deposit(@PathVariable String pesel,
                                        @RequestParam BigDecimal amount) {
        BankAccount account = bankAccountService.loadAccount(pesel);
        if (account != null) {
            account.deposit(amount);
            bankAccountService.saveAccount(account);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/{pesel}/withdraw")
    public ResponseEntity<Void> withdraw(@PathVariable String pesel,
                                         @RequestParam BigDecimal amount) {
        BankAccount account = bankAccountService.loadAccount(pesel);
        if (account != null) {
            account.withdraw(amount);
            bankAccountService.saveAccount(account);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/transfer")
    public ResponseEntity<Void> transfer(@RequestParam String sourcePesel,
                                         @RequestParam String targetPesel,
                                         @RequestParam BigDecimal amount) {
        bankAccountService.transfer(sourcePesel, targetPesel, amount);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{pesel}/history")
    public ResponseEntity<List<Transaction>> getHistory(@PathVariable String pesel) {
        BankAccount account = bankAccountService.loadAccount(pesel);
        if (account != null) {
            return ResponseEntity.ok(account.getTransactionHistory());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{pesel}")
    public ResponseEntity<Void> deleteAccount(@PathVariable String pesel) throws IOException {
        BankAccount account = bankAccountService.loadAccount(pesel);
        if (account != null) {
            bankAccountService.deleteAccount(pesel);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/{pesel}")
    public ResponseEntity<BankAccount> updateAccount(@PathVariable String pesel,
                                                     @RequestParam(required = false) String firstName,
                                                     @RequestParam(required = false) String lastName,
                                                     @RequestParam(required = false) String email
    ) {
        BankAccount existingAccount = bankAccountService.loadAccount(pesel);

        if (existingAccount != null) {
            if (firstName != null && !firstName.isBlank()) {
                existingAccount.setFirstName(firstName);
            }
            if (lastName != null && !lastName.isBlank()) {
                existingAccount.setLastName(lastName);
            }
            if (email != null && !email.isBlank()) {
                existingAccount.setEmail(email);
            }
            bankAccountService.saveAccount(existingAccount);

            return ResponseEntity.ok(existingAccount);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}