package org.pysiakwyderski.lab2.studentbanking.services;

import org.pysiakwyderski.lab2.studentbanking.models.BankAccount;
import org.pysiakwyderski.lab2.studentbanking.file.FileOperations;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import jakarta.annotation.PostConstruct;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BankAccountService {

    private final FileOperations fileOperations;
    private final ObjectMapper objectMapper;
    private final Map<String, BankAccount> accountCache = new HashMap<>();

    @Autowired
    public BankAccountService(FileOperations fileOperations, ObjectMapper objectMapper) {
        this.fileOperations = fileOperations;
        this.objectMapper = objectMapper;
    }

    @PostConstruct
    public void init() {
        Path dataDir = Paths.get("data/");

        try {
            Files.createDirectories(dataDir);

            List<Path> jsonFiles = Files.list(dataDir)
                    .filter(path -> path.toString().endsWith(".json"))
                    .toList();

            for (Path path : jsonFiles) {
                try {
                    String json = Files.readString(path);
                    BankAccount account = objectMapper.readValue(json, BankAccount.class);
                    accountCache.put(account.getPesel(), account);
                } catch (IOException e) {
                    System.err.printf("Error reading file %s: %s%n", path, e.getMessage());
                } catch (Exception e) {
                    System.err.printf("Failed to load account from %s: %s%n", path, e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Failed to initialize accounts directory: " + e.getMessage());
        }
    }

    public void saveAccount(BankAccount account) {
        String filename = account.getPesel();
        fileOperations.saveToFile(filename, account.toJson());
        accountCache.put(account.getPesel(), account);
    }

    public BankAccount loadAccount(String pesel) {
        if (accountCache.containsKey(pesel)) {
            return accountCache.get(pesel);
        }

        String json = fileOperations.readFromFile(pesel);
        if (json == null || json.isBlank()) {
            return null;
        }

        try {
            BankAccount account = objectMapper.readValue(json, BankAccount.class);
            accountCache.put(pesel, account);
            return account;
        } catch (Exception e) {
            return null;
        }
    }

    public void transfer(String sourcePesel, String targetPesel, BigDecimal amount) {
        BankAccount sourceAccount = loadAccount(sourcePesel);
        BankAccount targetAccount = loadAccount(targetPesel);

        if (sourceAccount != null && targetAccount != null) {
            sourceAccount.transfer(targetAccount, amount);
            saveAccount(sourceAccount);
            saveAccount(targetAccount);
        } else {
            throw new IllegalArgumentException("One or both accounts not found");
        }
    }

    public void deleteAccount(String pesel) {
        BankAccount account = accountCache.get(pesel);
        if (account != null) {
            accountCache.remove(pesel);
            fileOperations.deleteFile(account.getPesel());
        }
    }
}