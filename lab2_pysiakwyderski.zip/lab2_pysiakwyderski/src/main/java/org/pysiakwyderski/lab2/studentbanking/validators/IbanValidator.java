package org.pysiakwyderski.lab2.studentbanking.validators;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;



public class IbanValidator implements ConstraintValidator<ValidIban, String> {


    private static final Map<String, Integer> COUNTRY_CODE_TO_LENGTH = new HashMap<>();

    static {
        COUNTRY_CODE_TO_LENGTH.put("AD", 24); // Andora
        COUNTRY_CODE_TO_LENGTH.put("AE", 23); // Zjednoczone Emiraty Arabskie
        COUNTRY_CODE_TO_LENGTH.put("AL", 28); // Albania
        COUNTRY_CODE_TO_LENGTH.put("AT", 20); // Austria
        COUNTRY_CODE_TO_LENGTH.put("AZ", 28); // Azerbejdżan
        COUNTRY_CODE_TO_LENGTH.put("BA", 20); // Bośnia i Hercegowina
        COUNTRY_CODE_TO_LENGTH.put("BE", 16); // Belgia
        COUNTRY_CODE_TO_LENGTH.put("BG", 22); // Bułgaria
        COUNTRY_CODE_TO_LENGTH.put("BH", 22); // Bahrajn
        COUNTRY_CODE_TO_LENGTH.put("BR", 29); // Brazylia
        COUNTRY_CODE_TO_LENGTH.put("BY", 28); // Białoruś
        COUNTRY_CODE_TO_LENGTH.put("CH", 21); // Szwajcaria
        COUNTRY_CODE_TO_LENGTH.put("CR", 22); // Kostaryka
        COUNTRY_CODE_TO_LENGTH.put("CY", 28); // Cypr
        COUNTRY_CODE_TO_LENGTH.put("CZ", 24); // Czechy
        COUNTRY_CODE_TO_LENGTH.put("DE", 22); // Niemcy
        COUNTRY_CODE_TO_LENGTH.put("DK", 18); // Dania
        COUNTRY_CODE_TO_LENGTH.put("DO", 28); // Dominikana
        COUNTRY_CODE_TO_LENGTH.put("EE", 20); // Estonia
        COUNTRY_CODE_TO_LENGTH.put("EG", 29); // Egipt
        COUNTRY_CODE_TO_LENGTH.put("ES", 24); // Hiszpania
        COUNTRY_CODE_TO_LENGTH.put("FI", 18); // Finlandia
        COUNTRY_CODE_TO_LENGTH.put("FO", 18); // Wyspy Owcze
        COUNTRY_CODE_TO_LENGTH.put("FR", 27); // Francja
        COUNTRY_CODE_TO_LENGTH.put("GB", 22); // Wielka Brytania
        COUNTRY_CODE_TO_LENGTH.put("GE", 22); // Gruzja
        COUNTRY_CODE_TO_LENGTH.put("GI", 23); // Gibraltar
        COUNTRY_CODE_TO_LENGTH.put("GL", 18); // Grenlandia
        COUNTRY_CODE_TO_LENGTH.put("GR", 27); // Grecja
        COUNTRY_CODE_TO_LENGTH.put("GT", 28); // Gwatemala
        COUNTRY_CODE_TO_LENGTH.put("HR", 21); // Chorwacja
        COUNTRY_CODE_TO_LENGTH.put("HU", 28); // Węgry
        COUNTRY_CODE_TO_LENGTH.put("IE", 22); // Irlandia
        COUNTRY_CODE_TO_LENGTH.put("IL", 23); // Izrael
        COUNTRY_CODE_TO_LENGTH.put("IQ", 23); // Irak
        COUNTRY_CODE_TO_LENGTH.put("IS", 26); // Islandia
        COUNTRY_CODE_TO_LENGTH.put("IT", 27); // Włochy
        COUNTRY_CODE_TO_LENGTH.put("JO", 30); // Jordania
        COUNTRY_CODE_TO_LENGTH.put("KW", 30); // Kuwejt
        COUNTRY_CODE_TO_LENGTH.put("KZ", 20); // Kazachstan
        COUNTRY_CODE_TO_LENGTH.put("LB", 28); // Liban
        COUNTRY_CODE_TO_LENGTH.put("LC", 32); // Saint Lucia
        COUNTRY_CODE_TO_LENGTH.put("LI", 21); // Liechtenstein
        COUNTRY_CODE_TO_LENGTH.put("LT", 20); // Litwa
        COUNTRY_CODE_TO_LENGTH.put("LU", 20); // Luksemburg
        COUNTRY_CODE_TO_LENGTH.put("LV", 21); // Łotwa
        COUNTRY_CODE_TO_LENGTH.put("MC", 27); // Monako
        COUNTRY_CODE_TO_LENGTH.put("MD", 24); // Mołdawia
        COUNTRY_CODE_TO_LENGTH.put("ME", 22); // Czarnogóra
        COUNTRY_CODE_TO_LENGTH.put("MK", 19); // Macedonia Północna
        COUNTRY_CODE_TO_LENGTH.put("MR", 27); // Mauretania
        COUNTRY_CODE_TO_LENGTH.put("MT", 31); // Malta
        COUNTRY_CODE_TO_LENGTH.put("MU", 30); // Mauritius
        COUNTRY_CODE_TO_LENGTH.put("NL", 18); // Holandia
        COUNTRY_CODE_TO_LENGTH.put("NO", 15); // Norwegia
        COUNTRY_CODE_TO_LENGTH.put("PK", 24); // Pakistan
        COUNTRY_CODE_TO_LENGTH.put("PL", 28); // Polska
        COUNTRY_CODE_TO_LENGTH.put("PS", 29); // Palestyna
        COUNTRY_CODE_TO_LENGTH.put("PT", 25); // Portugalia
        COUNTRY_CODE_TO_LENGTH.put("QA", 29); // Katar
        COUNTRY_CODE_TO_LENGTH.put("RO", 24); // Rumunia
        COUNTRY_CODE_TO_LENGTH.put("RS", 22); // Serbia
        COUNTRY_CODE_TO_LENGTH.put("SA", 24); // Arabia Saudyjska
        COUNTRY_CODE_TO_LENGTH.put("SE", 24); // Szwecja
        COUNTRY_CODE_TO_LENGTH.put("SI", 19); // Słowenia
        COUNTRY_CODE_TO_LENGTH.put("SK", 24); // Słowacja
        COUNTRY_CODE_TO_LENGTH.put("SM", 27); // San Marino
        COUNTRY_CODE_TO_LENGTH.put("ST", 25); // Wyspy Świętego Tomasza i Książęca
        COUNTRY_CODE_TO_LENGTH.put("SV", 28); // Salwador
        COUNTRY_CODE_TO_LENGTH.put("TL", 23); // Timor Wschodni
        COUNTRY_CODE_TO_LENGTH.put("TN", 24); // Tunezja
        COUNTRY_CODE_TO_LENGTH.put("TR", 26); // Turcja
        COUNTRY_CODE_TO_LENGTH.put("UA", 29); // Ukraina
        COUNTRY_CODE_TO_LENGTH.put("VA", 22); // Watykan
        COUNTRY_CODE_TO_LENGTH.put("VG", 24); // Brytyjskie Wyspy Dziewicze
        COUNTRY_CODE_TO_LENGTH.put("XK", 20); // Kosowo
    }



    @Override
    public void initialize(ValidIban constraintAnnotation) {
    }


    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null || value.isEmpty()) {
            return true;
        }

        return validateIban(value);
    }



    private boolean validateIban(String iban) {
        String normalizedIban = iban.replaceAll("\\s", "").toUpperCase();

        if (normalizedIban.length() < 5) {
            return false;
        }

        String countryCode = normalizedIban.substring(0, 2);

        if (!countryCode.matches("[A-Z]{2}")) {
            return false;
        }

        Integer expectedLength = COUNTRY_CODE_TO_LENGTH.get(countryCode);
        if (expectedLength == null) {
            return false;
        }

        if (normalizedIban.length() != expectedLength) {
            return false;
        }
        String rearrangedIban = normalizedIban.substring(4) + normalizedIban.substring(0, 4);

        StringBuilder numericRepresentation = new StringBuilder();
        for (char c : rearrangedIban.toCharArray()) {
            if (Character.isLetter(c)) {
                numericRepresentation.append(Character.getNumericValue(c));
            } else if (Character.isDigit(c)) {
                numericRepresentation.append(c);
            } else {
                return false;
            }
        }

        try {
            BigInteger numericValue = new BigInteger(numericRepresentation.toString());
            BigInteger mod = numericValue.mod(BigInteger.valueOf(97));

            return mod.intValue() == 1;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}

