package org.pysiakwyderski.lab2.studentbanking.operations;

import org.pysiakwyderski.lab2.studentbanking.models.BankAccount;
import org.pysiakwyderski.lab2.studentbanking.models.Transaction;

import java.math.BigDecimal;
import java.util.List;

public interface BankAccountOperations {

    void deposit(BigDecimal amount);

    void withdraw(BigDecimal amount);

    void transfer(BankAccount targetAccount, BigDecimal amount);

    List<Transaction> getTransactionHistory();
}
