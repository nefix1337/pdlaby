package org.pysiakwyderski.lab2.studentbanking.file;

public interface FileOperations {

    void saveToFile(String filename, String content);

    String readFromFile(String filename);

    void deleteFile(String filename);
}
