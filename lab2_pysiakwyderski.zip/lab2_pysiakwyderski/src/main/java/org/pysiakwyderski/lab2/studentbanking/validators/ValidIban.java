package org.pysiakwyderski.lab2.studentbanking.validators;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to validate whether a given field or parameter contains a valid IBAN (International Bank Account Number).
 * This annotation can be used on fields or method parameters to enforce IBAN validation logic through the associated
 * validator class {@code IbanValidator}.
 *
 * Constraints:
 * - Supports validation of IBAN in compliance with the IBAN format standards.
 * - By default, produces an error message "Invalid IBAN number" when the validation fails.
 *
 * Attributes:
 * - `message`: Customizable error message for validation failure.
 * - `groups`: Enables grouping of constraints for selective validation.
 * - `payload`: Associates custom metadata with the constraint.
 *
 * Target:
 * - This annotation can be applied to fields and parameters.
 *
 * Retention Policy:
 * - This annotation is retained at runtime.
 *
 * Usage requires the specification of the {@code IbanValidator} class to define the validation logic.
 */
@Constraint(validatedBy = IbanValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidIban {
    String message() default "Invalid IBAN number";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}