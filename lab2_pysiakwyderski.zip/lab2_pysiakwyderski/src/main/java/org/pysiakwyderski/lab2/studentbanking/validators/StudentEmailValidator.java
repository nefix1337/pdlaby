package org.pysiakwyderski.lab2.studentbanking.validators;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class StudentEmailValidator implements ConstraintValidator<ValidStudentEmail, String> {

    private static final String STUDENT_EMAIL_PATTERN = "^s\\d{5}@student\\.tu\\.kielce\\.pl$";


    @Override
    public boolean isValid(String email, ConstraintValidatorContext context) {
        if (email == null) {
            return false;
        }
        return email.matches(STUDENT_EMAIL_PATTERN);
    }
}