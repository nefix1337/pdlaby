package org.pysiakwyderski.lab2.studentbanking.models;

import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.pysiakwyderski.lab2.studentbanking.operations.BankAccountOperations;
import org.pysiakwyderski.lab2.studentbanking.json.JsonSerializable;
import org.pysiakwyderski.lab2.studentbanking.validators.ValidIban;
import org.pysiakwyderski.lab2.studentbanking.validators.ValidPesel;
import org.pysiakwyderski.lab2.studentbanking.validators.ValidStudentEmail;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data

@AllArgsConstructor
public class BankAccount implements BankAccountOperations, JsonSerializable {

    @NotBlank(message = "First name cannot be blank")
    private String firstName;


    @NotBlank(message = "Last name cannot be blank")
    private String lastName;

    @ValidIban
    @NotBlank(message = "Account number cannot be blank")
    private String accountNumber;


    @NotNull(message = "Balance cannot be null")
    private BigDecimal balance = BigDecimal.ZERO;


    private List<Transaction> transactionHistory = new ArrayList<>();


    @ValidPesel
    @NotBlank(message = "PESEL cannot be blank")
    private String pesel;


    @ValidStudentEmail
    @NotBlank(message = "Email cannot be blank")
    private String email;

    private static final BigDecimal FEE_DOMESTIC_TRANSFER = new BigDecimal("2.00");
    private static final BigDecimal FEE_INTERNATIONAL_TRANSFER_MIN = new BigDecimal("10.00");
    private static final BigDecimal FEE_INTERNATIONAL_TRANSFER_RATE = new BigDecimal("0.15");

    @Override
    public void deposit(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        balance = balance.add(amount);
        transactionHistory.add(new Transaction("DEPOSIT", amount, "Deposit to account"));
    }


    @Override
    public void withdraw(BigDecimal amount) {
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        if (balance.compareTo(amount) < 0) {
            throw new IllegalArgumentException("Insufficient funds");
        }
        balance = balance.subtract(amount);
        transactionHistory.add(new Transaction("WITHDRAWAL", amount, "Withdrawal from account"));
    }


    @Override
    public void transfer(BankAccount targetAccount, BigDecimal amount) {
        if (targetAccount == null) {
            throw new IllegalArgumentException("Target account cannot be null");
        }
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Transfer amount must be positive");
        }


        BigDecimal fee = calculateTransferFee(targetAccount, amount);


        BigDecimal totalAmount = amount.add(fee);
        if (balance.compareTo(totalAmount) < 0) {
            throw new IllegalArgumentException("Insufficient funds to cover transfer amount and fees");
        }


        balance = balance.subtract(totalAmount);


        transactionHistory.add(new Transaction("TRANSFER", amount, "Transfer to " + targetAccount.getAccountNumber()));


        String feeDescription = targetAccount.getAccountNumber().startsWith("PL")
                ? "Domestic transfer fee to:"
                : "International transfer fee to:";

        transactionHistory.add(new Transaction("FEE", fee, feeDescription + targetAccount.getBalance()));

        targetAccount.deposit(amount);
    }




    private BigDecimal calculateTransferFee(BankAccount targetAccount, BigDecimal amount) {
        if (targetAccount.getAccountNumber().startsWith("PL")) {
            return FEE_DOMESTIC_TRANSFER;
        } else {

            BigDecimal percentageFee = amount.multiply(FEE_INTERNATIONAL_TRANSFER_RATE);
            return percentageFee.compareTo(FEE_INTERNATIONAL_TRANSFER_MIN) > 0
                    ? percentageFee
                    : FEE_INTERNATIONAL_TRANSFER_MIN;
        }
    }


    @Override
    public List<Transaction> getTransactionHistory() {
        return new ArrayList<>(transactionHistory);
    }


    @Override
    public String toJson() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            return mapper.writeValueAsString(this);
        } catch (Exception e) {
            throw new RuntimeException("Error serializing to JSON", e);
        }
    }


    public BankAccount() {
    }
}