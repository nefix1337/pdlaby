package org.pysiakwyderski.lab2.studentbanking.file;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Component
public class FileOperationsImpl implements FileOperations {

    private static final String DATA_DIR = "data/";
    private static final String FILE_TYPE = ".json";


    @Override
    public void saveToFile(String filename, String content) {
        try {
            Files.createDirectories(Paths.get(DATA_DIR));
            Files.writeString(Paths.get(DATA_DIR + filename + FILE_TYPE), content);
        } catch (IOException e) {
            throw new RuntimeException("Error saving to file", e);
        }
    }


    @Override
    public String readFromFile(String filename) {
        try {
            return Files.readString(Paths.get(DATA_DIR + filename + FILE_TYPE));
        } catch (IOException e) {
            return null;
        }
    }

    @Override
    public void deleteFile(String filename) {
        try{
            Files.deleteIfExists(Paths.get(DATA_DIR + filename + FILE_TYPE));
        } catch (IOException e) {
            throw new RuntimeException("Error saving to file", e);
        }


    }
}

