package org.pysiakwyderski.lab2.studentbanking.validators;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to validate whether a given field or parameter contains a valid PESEL (Polish national identification number).
 * This annotation can be used on fields or method parameters to enforce PESEL validation logic through the associated
 * validator class {@code PeselValidator}.
 *
 * Constraints:
 * - Checks if the PESEL consists of exactly 11 numeric characters.
 * - Validates the checksum to ensure correctness of the PESEL.
 * - By default, produces an error message "Invalid PESEL number" when the validation fails.
 *
 * Attributes:
 * - `message`: Customizable error message for validation failure.
 * - `groups`: Enables grouping of constraints for selective validation.
 * - `payload`: Associates custom metadata with the constraint.
 *
 * Target:
 * - This annotation can be applied to fields and parameters.
 *
 * Retention Policy:
 * - This annotation is retained at runtime.
 *
 * The validation logic is implemented in the {@code PeselValidator} class.
 */
@Constraint(validatedBy = PeselValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidPesel {
    String message() default "Invalid PESEL number";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
