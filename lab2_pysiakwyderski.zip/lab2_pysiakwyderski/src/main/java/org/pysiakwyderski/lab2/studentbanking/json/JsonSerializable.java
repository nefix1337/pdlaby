package org.pysiakwyderski.lab2.studentbanking.json;

public interface JsonSerializable {

    String toJson();
}
