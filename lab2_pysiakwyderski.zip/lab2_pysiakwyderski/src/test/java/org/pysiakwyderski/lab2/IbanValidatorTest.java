package org.pysiakwyderski.lab2;

import org.springframework.boot.test.context.SpringBootTest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.pysiakwyderski.lab2.studentbanking.validators.IbanValidator;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class IbanValidatorTest {

    private IbanValidator ibanValidator;

    @BeforeEach
    void setUp() {
        ibanValidator = new IbanValidator();
    }

    @Nested
    @DisplayName("Poprawne numery IBAN")
    class ValidIbanTests {

        @ParameterizedTest
        @ValueSource(strings = {
                "PL61109010140000071219812874", // Poprawny IBAN polski (28 znaków)
                "DE89370400440532013000", // Poprawny IBAN niemiecki (22 znaki)
                "GB29NWBK60161331926819", // Poprawny IBAN brytyjski (22 znaki)
                "FR1420041010050500013M02606", // Poprawny IBAN francuski (27 znaków)
                "IT60X0542811101000000123456" // Poprawny IBAN włoski (27 znaków)
        })
        @DisplayName("Powinny zostać uznane za poprawne")
        void shouldValidateCorrectlyFormattedIbans(String iban) {
            assertTrue(ibanValidator.isValid(iban, null));
        }

        @ParameterizedTest
        @ValueSource(strings = {
                "PL 61 1090 1014 0000 0712 1981 2874", // Polski IBAN ze spacjami
                "DE89 3704 0044 0532 0130 00", // Niemiecki IBAN ze spacjami
                "GB29 NWBK 6016 1331 9268 19" // Brytyjski IBAN ze spacjami
        })
        @DisplayName("Powinien zaakceptować numery IBAN zawierające spacje")
        void shouldValidateIbansWithSpaces(String iban) {
            assertTrue(ibanValidator.isValid(iban, null));
        }

        @Test
        @DisplayName("Powinien zaakceptować numer IBAN z różną wielkością liter")
        void shouldValidateMixedCaseIban() {
            assertTrue(ibanValidator.isValid("pL61109010140000071219812874", null));
        }
    }

    @Nested
    @DisplayName("Niepoprawne numery IBAN")
    class InvalidIbanTests {

        @ParameterizedTest
        @ValueSource(strings = {
                "PL6110901014000007121981287",  // Za krótki (27 zamiast 28 znaków)
                "DE8937040044053201300", // Za krótki (21 zamiast 22 znaków)
                "PL611090101400000712198128745", // Za długi (29 zamiast 28 znaków)
                "XX61109010140000071219812874", // Nieznany kod kraju (XX)
                "P161109010140000071219812874" // Błędny kod kraju (P1 zamiast PL)
        })
        void shouldRejectInvalidLengthOrCountry(String iban) {
            assertFalse(ibanValidator.isValid(iban, null));
        }

        @ParameterizedTest
        @ValueSource(strings = {
                "PL61109010140000071219812875", // Błędna suma kontrolna (75 zamiast 74)
                "PL611O9010140000071219812874", // Litera 'O' zamiast zera
                "PL61!09010140000071219812874", // Niedozwolony znak specjalny (!)
                "1234567890123456789012345678" // Tylko cyfry (brak kodu kraju)
        })
        void shouldRejectInvalidCharactersOrChecksum(String iban) {
            assertFalse(ibanValidator.isValid(iban, null));
        }
    }

    @Nested
    @DisplayName("Testy przypadków brzegowych")
    class EdgeCasesTests {

        @ParameterizedTest
        @NullSource
        @EmptySource
        @ValueSource(strings = { "" })
        @DisplayName("Puste i null IBAN-y powinny być traktowane jako poprawne")
        void shouldAllowEmptyOrNullValues(String iban) {
            assertTrue(ibanValidator.isValid(iban, null));
        }


        @ParameterizedTest
        @ValueSource(strings = {
                " PL10 1050 0099 7603 1234 5678 9123 ",// spacje na początku i końcu
                "pl10105000997603123456789123",// małe litery
                "Pl10105000997603123456789123",// mieszane litery

        })
        @DisplayName("Poprawne IBAN-y z różnym formatowaniem")
        void shouldHandleFormattedIbans(String iban) {

            assertTrue(ibanValidator.isValid(iban, null));
        }

        @ParameterizedTest
        @ValueSource(strings = {
                "PL",// za krótki
                "PL10",// tylko prefix
                "PL1010",// fragment IBAN-u
                "P",// tylko jedna litera
                "PL!@#$$%%",// znaki specjalne
                "PL10\t1050\n0099",// znaki białe w środku bez poprawnej długości
                "PŁ10105000997603123456789123",// polski znak w IBAN

        })
        @DisplayName("IBAN-y o nieprawidłowych lub dziwnych formatach powinny być odrzucone")
        void shouldRejectWeirdOrInvalidFormats(String iban) {
            assertFalse(ibanValidator.isValid(iban, null));
        }
    }




}
