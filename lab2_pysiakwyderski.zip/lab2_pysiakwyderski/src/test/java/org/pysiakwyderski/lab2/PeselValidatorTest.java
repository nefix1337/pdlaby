package org.pysiakwyderski.lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;
import org.pysiakwyderski.lab2.studentbanking.validators.PeselValidator;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class PeselValidatorTest {

    private PeselValidator peselValidator;

    @BeforeEach
    void setUp() {
        peselValidator = new PeselValidator();
    }

    @Nested
    @DisplayName("Poprawne numery PESEL")
    class ValidPeselTests {

        @ParameterizedTest
        @ValueSource(strings = {
                "44051401359", // 14.05.1944
                "00222912370"  // 29.02.2000 - przestępny
        })
        @DisplayName("Powinny być uznane za poprawne")
        void shouldAcceptValidPesel(String pesel) {
            assertTrue(peselValidator.isValid(pesel, null));
        }
    }

    @Nested
    @DisplayName("Niepoprawne numery PESEL")
    class InvalidPeselTests {

        @ParameterizedTest
        @ValueSource(strings = {
                "44051401358", // zła suma kontrolna
                "02211301457", // zła suma
                "99123112365", // zła suma
                "abcdefghijk", // litery
                "123456789",   // za krótki
                "123456789012",// za długi
                "12345!78901", // znak specjalny
                "1234567890a"  // ostatni znak litera
        })
        @DisplayName("Powinny być uznane za niepoprawne")
        void shouldRejectInvalidPesel(String pesel) {
            assertFalse(peselValidator.isValid(pesel, null));
        }
    }


    @Nested
    @DisplayName("Testy sumy kontrolnej")
    class ChecksumTests {

        @ParameterizedTest
        @ValueSource(strings = {
                "44051401359", // poprawna suma
                "02070803628", // poprawna suma

        })
        @DisplayName("Poprawna suma kontrolna")
        void shouldValidateCorrectChecksum(String pesel) {
            assertTrue(peselValidator.isValid(pesel, null));
        }

        @ParameterizedTest
        @ValueSource(strings = {
                "44051401358", // błędna suma
                "02070803627", // błędna suma

        })
        @DisplayName("Błędna suma kontrolna")
        void shouldInvalidateIncorrectChecksum(String pesel) {
            assertFalse(peselValidator.isValid(pesel, null));
        }
    }

    @Nested
    @DisplayName("Testy przypadków brzegowych")
    class EdgeCaseTests {

        @ParameterizedTest
        @NullSource
        @EmptySource
        @ValueSource(strings = {
                "",        // pusty ciąg
                " ",       // spacja
                "123",     // za krótki
                "1234567890123", // za długi
                "\t\n",    // białe znaki

        })
        @DisplayName("Niepoprawne długości lub formaty")
        void shouldRejectEdgeCases(String pesel) {
            assertFalse(peselValidator.isValid(pesel, null));
        }
    }


}
