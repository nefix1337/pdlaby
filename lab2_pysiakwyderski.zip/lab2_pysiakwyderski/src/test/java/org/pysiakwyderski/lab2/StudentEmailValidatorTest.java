package org.pysiakwyderski.lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;
import org.pysiakwyderski.lab2.studentbanking.validators.StudentEmailValidator;

import static org.junit.jupiter.api.Assertions.*;

public class StudentEmailValidatorTest {


    private StudentEmailValidator emailValidator;

    @BeforeEach
    void setUp() {
        emailValidator = new StudentEmailValidator();
    }


    @Nested
    @DisplayName("Poprawne adresy email")
    class ValidEmails {

        @ParameterizedTest
        @ValueSource(strings = {
                "s12345@student.tu.kielce.pl",
                "s00000@student.tu.kielce.pl",
                "s99999@student.tu.kielce.pl",
                "s92839@student.tu.kielce.pl"

        })
        @DisplayName("Powinny być uznane za poprawne")
        void shouldAcceptValidStudentEmails(String email) {
            assertTrue(emailValidator.isValid(email, null));
        }
    }


    @Nested
    @DisplayName("Niepoprawne adresy email")
    class InvalidEmails {

        @ParameterizedTest
        @ValueSource(strings = {
                "x12345@student.tu.kielce.pl",// zła litera
                "S12345@student.tu.kielce.pl",// wielka litera
                "ss12345@student.tu.kielce.pl", // podwójne 's'
                "12345@student.tu.kielce.pl", // brak litery 's'
                "@student.tu.kielce.pl",// brak identyfikatora
                "s12345@studenciak.tu.kielce.pl",// zła domena
                "s12345@student.tu.kielce.pl ",// spacja na końcu
                " s12345@student.tu.kielce.pl",// spacja na początku
        })
        @DisplayName("Powinny zostać odrzucone jako niepoprawne")
        void shouldRejectInvalidStudentEmails(String email) {
            assertFalse(emailValidator.isValid(email, null));
        }
    }

    @Nested
    @DisplayName("Testy przypadków brzegowych")
    class EdgeCases {

        @ParameterizedTest
        @ValueSource(strings = {
                "", "   ", "\n", "\t"
        })
        @DisplayName("Puste lub białe znaki powinnu być niepoprawne")
        void shouldRejectBlankEmails(String email) {
            assertFalse(emailValidator.isValid(email, null));
        }

        @ParameterizedTest
        @NullSource
        @DisplayName("Null powinien być niepoprawny")
        void shouldRejectNull(String email) {
            assertFalse(emailValidator.isValid(email, null));
        }

        @ParameterizedTest
        @DisplayName("Niepoprawne adresy z białymi znakami na początku")
        @ValueSource(strings = {
                " s12345@student.tu.kielce.pl",// spacja na początku
                "\ts12345@student.tu.kielce.pl"// tabulator na początku
        })
        void shouldRejectEmailsWithWhitespaceAtStart(String email) {
            assertFalse(emailValidator.isValid(email, null));
        }

        @ParameterizedTest
        @DisplayName("Niepoprawne adresy z białymi znakami na końcu")
        @ValueSource(strings = {
                "s12345@student.tu.kielce.pl ",// spacja na końcu
                "s12345@student.tu.kielce.pl\n"// nowa linia na końcu
        })
        void shouldRejectEmailsWithWhitespaceAtEnd(String email) {
            assertFalse(emailValidator.isValid(email, null));
        }
    }


}
