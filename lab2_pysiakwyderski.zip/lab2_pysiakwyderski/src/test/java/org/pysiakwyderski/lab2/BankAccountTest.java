package org.pysiakwyderski.lab2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.context.SpringBootTest;
import org.pysiakwyderski.lab2.studentbanking.models.BankAccount;
import org.pysiakwyderski.lab2.studentbanking.models.Transaction;

import java.math.BigDecimal;
import java.util.List;


import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class BankAccountTest {


    private BankAccount sourceAccount;
    private BankAccount domesticAccount;
    private BankAccount internationalAccount;

    // Stałe testowe
    private static final BigDecimal INITIAL_BALANCE = new BigDecimal("1000.00");
    private static final BigDecimal DOMESTIC_FEE = new BigDecimal("2.00");
    private static final BigDecimal MIN_INTERNATIONAL_FEE = new BigDecimal("10.00");


    @BeforeEach
    void setUp() {

        sourceAccount = createAccount("Jan",
                "Kowalski",
                "PL61109010140000071219812874",
                "90090515030",
                "s12345@student.tu.kielce.pl");
        sourceAccount.setBalance(INITIAL_BALANCE);

        domesticAccount = createAccount("Anna",
                "Nowak",
                "PL61109010140000071219812875",
                "90090515031",
                "s12346@student.tu.kielce.pl");
        domesticAccount.setBalance(BigDecimal.ZERO);

        internationalAccount = createAccount("John",
                "Smith",
                "DE89370400440532013000",
                "90090515032",
                "s12347@student.tu.kielce.pl");
        internationalAccount.setBalance(BigDecimal.ZERO);
    }

    private BankAccount createAccount(String firstName, String lastName, String accountNumber, String pesel, String email) {
        BankAccount account = new BankAccount();
        account.setFirstName(firstName);
        account.setLastName(lastName);
        account.setAccountNumber(accountNumber);
        account.setPesel(pesel);
        account.setEmail(email);
        return account;
    }

    @Nested
    @DisplayName("a) Testy Happy Path")
    class HappyPathTests {

        @Test
        @DisplayName("Test weryfikujący, czy przelew krajowy pobiera stałą opłatę 2,00 PLN")
        void domesticTransferShouldChargeFixedFee() {

            BigDecimal transferAmount = new BigDecimal("100.00");
            BigDecimal expectedSourceBalance = INITIAL_BALANCE.subtract(transferAmount).subtract(DOMESTIC_FEE);

            sourceAccount.transfer(domesticAccount, transferAmount);

            assertEquals(expectedSourceBalance, sourceAccount.getBalance(),
                    "Saldo konta źródłowego powinno być pomniejszone o kwotę przelewu i stałą opłatę 2,00 PLN");
            assertEquals(transferAmount, domesticAccount.getBalance(),
                    "Saldo konta docelowego powinno być powiększone o kwotę przelewu");
        }

        @Test
        @DisplayName("Test weryfikujący, czy przelew międzynarodowy pobiera opłatę 15% kwoty lub minimum 10,00 PLN")
        void internationalTransferShouldChargePercentageOrMinimumFee() {

            BigDecimal transferAmount = new BigDecimal("100.00");
            BigDecimal percentageFee = transferAmount.multiply(new BigDecimal("0.15"));
            BigDecimal expectedSourceBalance = INITIAL_BALANCE.subtract(transferAmount).subtract(percentageFee);


            sourceAccount.transfer(internationalAccount, transferAmount);

            assertEquals(expectedSourceBalance, sourceAccount.getBalance(),
                    "Saldo konta źródłowego powinno być pomniejszone o kwotę przelewu i opłatę 15%");
            assertEquals(transferAmount, internationalAccount.getBalance(),
                    "Saldo konta docelowego powinno być powiększone o kwotę przelewu");
        }

        @Test
        @DisplayName("Test weryfikujący, czy historia transakcji zawiera wpisy o przelewie i opłacie")
        void transactionHistoryShouldContainTransferAndFeeEntries() {
            BigDecimal transferAmount = new BigDecimal("50.00");

            sourceAccount.transfer(domesticAccount, transferAmount);
            List<Transaction> history = sourceAccount.getTransactionHistory();

            assertEquals(2, history.size(), "Historia transakcji powinna zawierać 2 wpisy: przelew i opłata");

            Transaction transferTransaction = history.get(0);
            assertEquals("TRANSFER", transferTransaction.getType(), "Pierwszy wpis powinien być typu TRANSFER");
            assertEquals(transferAmount, transferTransaction.getAmount(), "Kwota przelewu powinna być zgodna");
            assertTrue(transferTransaction.getDescription().contains("Transfer to"), "Opis powinien zawierać informację o przelewie");

            Transaction feeTransaction = history.get(1);
            assertEquals("FEE", feeTransaction.getType(), "Drugi wpis powinien być typu FEE");
            assertEquals(DOMESTIC_FEE, feeTransaction.getAmount(), "Kwota opłaty powinna wynosić 2,00 PLN");
            assertTrue(feeTransaction.getDescription().contains("Domestic transfer fee"), "Opis powinien zawierać informację o opłacie");
        }
    }

    @Nested
    @DisplayName("b) Testy przypadków brzegowych (Edge Cases)")
    class EdgeCaseTests {

        @Test
        @DisplayName("Test dla przelewu krajowego o wysokiej wartości (powinna być pobierana stała opłata)")
        void highValueDomesticTransferShouldChargeFixedFee() {

            BigDecimal highAmount = new BigDecimal("10000.00");
            sourceAccount.setBalance(highAmount.add(DOMESTIC_FEE)); // zapewnienie wystarczających środków
            BigDecimal expectedSourceBalance = sourceAccount.getBalance().subtract(highAmount).subtract(DOMESTIC_FEE);

            sourceAccount.transfer(domesticAccount, highAmount);

            assertEquals(expectedSourceBalance, sourceAccount.getBalance(),
                    "Saldo konta źródłowego powinno być pomniejszone o kwotę przelewu i stałą opłatę 2,00 PLN");
            assertEquals(highAmount, domesticAccount.getBalance(),
                    "Saldo konta docelowego powinno być powiększone o kwotę przelewu");
        }

        @Test
        @DisplayName("Test dla przelewu międzynarodowego o bardzo niskiej wartości (powinna być pobierana minimalna opłata 10,00 PLN)")
        void lowValueInternationalTransferShouldChargeMinimumFee() {

            BigDecimal lowAmount = new BigDecimal("10.00");
            BigDecimal percentageFee = lowAmount.multiply(new BigDecimal("0.15"));
            BigDecimal expectedFee = MIN_INTERNATIONAL_FEE; // powinno być minimum 10 PLN
            BigDecimal expectedSourceBalance = INITIAL_BALANCE.subtract(lowAmount).subtract(expectedFee);

            sourceAccount.transfer(internationalAccount, lowAmount);

            assertEquals(expectedSourceBalance, sourceAccount.getBalance(),
                    "Saldo konta źródłowego powinno być pomniejszone o kwotę przelewu i minimalną opłatę 10,00 PLN");
            assertEquals(lowAmount, internationalAccount.getBalance(),
                    "Saldo konta docelowego powinno być powiększone o kwotę przelewu");

            Transaction feeTransaction = sourceAccount.getTransactionHistory().get(1);
            assertEquals(expectedFee, feeTransaction.getAmount(),
                    "Opłata powinna wynosić 10,00 PLN jako minimalna opłata dla przelewu międzynarodowego");
        }

        @Test
        @DisplayName("Test dla przelewu o maksymalnej możliwej wartości dostępnego salda (całe saldo minus opłata)")
        void maxValueTransferShouldUseEntireBalanceMinusFee() {
            BigDecimal transferAmount = INITIAL_BALANCE.subtract(DOMESTIC_FEE);

            sourceAccount.transfer(domesticAccount, transferAmount);

            assertEquals(0, sourceAccount.getBalance().compareTo(BigDecimal.ZERO),
                    "Saldo konta źródłowego powinno być zerowe po przelewie maksymalnej kwoty");
            assertEquals(0, transferAmount.compareTo(domesticAccount.getBalance()),
                    "Saldo konta docelowego powinno być powiększone o kwotę przelewu");
        }
    }

    @Nested
    @DisplayName("c) Testy obsługi błędów (Error Handling)")
    class ErrorHandlingTests {

        @Test
        @DisplayName("Test dla przelewu z niewystarczającymi środkami na pokrycie opłaty")
        void transferWithInsufficientFundsForFeeShouldThrowException() {
            BigDecimal amount = INITIAL_BALANCE; // równe saldu, ale bez uwzględnienia opłaty

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                    () -> sourceAccount.transfer(domesticAccount, amount),
                    "Transfer z niewystarczającymi środkami na opłatę powinien rzucić wyjątek");

            assertTrue(exception.getMessage().contains("Insufficient funds"),
                    "Komunikat wyjątku powinien informować o niewystarczających środkach");
        }

        @ParameterizedTest
        @ValueSource(strings = {"0.00", "-10.00"})
        @DisplayName("Test dla przelewu z zerową lub ujemną kwotą")
        void transferWithZeroOrNegativeAmountShouldThrowException(String amountStr) {

            BigDecimal invalidAmount = new BigDecimal(amountStr);

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                    () -> sourceAccount.transfer(domesticAccount, invalidAmount),
                    "Transfer z zerową lub ujemną kwotą powinien rzucić wyjątek");

            assertTrue(exception.getMessage().contains("amount must be positive"),
                    "Komunikat wyjątku powinien informować, że kwota musi być dodatnia");
        }

        @Test
        @DisplayName("Test dla przelewu na null jako konto docelowe")
        void transferToNullAccountShouldThrowException() {

            BankAccount nullAccount = null;
            BigDecimal amount = new BigDecimal("100.00");

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                    () -> sourceAccount.transfer(nullAccount, amount),
                    "Transfer na null jako konto docelowe powinien rzucić wyjątek");

            assertTrue(exception.getMessage().contains("Target account cannot be null"),
                    "Komunikat wyjątku powinien informować, że konto docelowe nie może być nullem");
        }
    }
}